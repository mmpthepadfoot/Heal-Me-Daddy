package com.padfoot.firstplugin;

import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class Main extends JavaPlugin {

	@Override
	public void onEnable( ) {
		System.out.println("HEALING PLUGIN ENABLED!");
	}
	
	@Override
	public void onDisable() {
		System.out.println("HEALING PLUGIN DIABLED!");
	}
	
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
	
		if (cmd.getName().equals("healmedaddy")) {
			if (sender instanceof Player) {
				Player player = (Player) sender;
				
				player.sendMessage(ChatColor.DARK_RED + "Hello, " + ChatColor.GREEN + player.getName() + " your health has been restored!");
				player.setHealth(20.0);
			} else {
				System.out.println("You cannot use this command through console!");
			}
		}
	
		return false;
    }
}
